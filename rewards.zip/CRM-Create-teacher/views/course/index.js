/**
 * Created by hawang on 12/26/14.
 */

'use strict';

exports.init = function(req, res){
    res.render('course/index');
};